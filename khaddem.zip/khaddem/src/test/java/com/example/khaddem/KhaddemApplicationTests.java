package com.example.khaddem;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class KhaddemApplicationTests {

    @Test
    void contextLoads() {
    }

}
