package com.example.khaddem.entites;

import javax.persistence.*;
import java.io.Serializable;

@Entity
@Table( name = "DetailEquipe")
public class DetailsEquipe implements Serializable {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "idDetailEquipe")
    private Integer idDetailEquipe; // Clé primaires
    private String thematique;
    private Integer salle;

}