package com.example.khaddem;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class KhaddemApplication {

    public static void main(String[] args) {
        SpringApplication.run(KhaddemApplication.class, args);
    }

}
