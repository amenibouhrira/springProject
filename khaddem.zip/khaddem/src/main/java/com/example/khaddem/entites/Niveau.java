package com.example.khaddem.entites;

public enum Niveau {
    JUNIOR,
    SENIOR,
    EXPERT,
}