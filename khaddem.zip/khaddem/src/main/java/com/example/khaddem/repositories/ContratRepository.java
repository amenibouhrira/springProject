package com.example.khaddem.repositories;

import com.example.khaddem.entites.Contrat;
import com.example.khaddem.entites.Department;
import org.springframework.data.repository.CrudRepository;

public interface ContratRepository extends CrudRepository<Contrat,Integer> {

}
