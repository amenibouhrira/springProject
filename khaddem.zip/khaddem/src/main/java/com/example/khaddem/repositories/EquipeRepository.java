package com.example.khaddem.repositories;

import com.example.khaddem.entites.Equipe;
import org.springframework.data.repository.CrudRepository;

public interface EquipeRepository extends CrudRepository<Equipe,Integer> {

}
