package com.example.khaddem.entites;

public  enum Option {
    ALINFO,
    CRYPTE,
    ETUDIANT
}
