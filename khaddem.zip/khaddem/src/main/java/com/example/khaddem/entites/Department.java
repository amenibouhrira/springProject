package com.example.khaddem.entites;

import javax.persistence.*;
import java.io.Serializable;
import javax.persistence.*;
@Entity
@Table( name = "Department")
public class Department implements Serializable {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "idDepart")
    private Integer idDepart; // Clé primaire
    private String nomDepart;

}
