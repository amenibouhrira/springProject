package com.example.khaddem.repositories;

import com.example.khaddem.entites.Specialite;
import com.example.khaddem.entites.Universite;
import org.springframework.data.repository.CrudRepository;

public interface UniversiteRepository extends CrudRepository<Universite,Integer> {

}
